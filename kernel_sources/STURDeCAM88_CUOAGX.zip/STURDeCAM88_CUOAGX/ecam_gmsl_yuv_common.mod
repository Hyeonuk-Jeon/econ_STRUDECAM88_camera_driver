/home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.o /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/serdes.o /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/sysfs_operations.o /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/strm_mon_thrd.o

