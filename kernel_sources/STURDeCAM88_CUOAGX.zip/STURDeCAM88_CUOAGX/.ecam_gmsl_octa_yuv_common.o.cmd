cmd_/home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.o := /home/yy/camera_driver_build/tool_chain/bin/aarch64-linux-gcc -Wp,-MMD,/home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/.ecam_gmsl_octa_yuv_common.o.d  -nostdinc -isystem /home/yy/camera_driver_build/tool_chain/bin/../lib/gcc/aarch64-buildroot-linux-gnu/9.3.0/include -I/home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include -I./arch/arm64/include/generated -I/home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include -I./include -I/home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi -I./arch/arm64/include/generated/uapi -I/home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi -I./include/generated/uapi -include /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kconfig.h -include /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/compiler_types.h -D__KERNEL__ -mlittle-endian -DKASAN_SHADOW_SCALE_SHIFT=3 -fmacro-prefix-map=/home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/= -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Wno-format-security -std=gnu89 -mgeneral-regs-only -DCONFIG_CC_HAS_K_CONSTRAINT=1 -Wno-psabi -mabi=lp64 -fno-asynchronous-unwind-tables -fno-unwind-tables -mbranch-protection=none -DKASAN_SHADOW_SCALE_SHIFT=3 -fno-delete-null-pointer-checks -Wno-frame-address -Wno-format-truncation -Wno-format-overflow -Wno-address-of-packed-member -O2 --param=allow-store-data-races=0 -Wframe-larger-than=4096 -fstack-protector-strong -Wimplicit-fallthrough -Wno-unused-but-set-variable -Wno-unused-const-variable -fno-omit-frame-pointer -fno-optimize-sibling-calls -g -pg -Wdeclaration-after-statement -Wvla -Wno-pointer-sign -Wno-stringop-truncation -Wno-array-bounds -Wno-stringop-overflow -Wno-restrict -Wno-maybe-uninitialized -fno-strict-overflow -fno-stack-check -fconserve-stack -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -Wno-packed-not-aligned -mstack-protector-guard=sysreg -mstack-protector-guard-reg=sp_el0 -mstack-protector-guard-offset=1392 -Wunused-variable -Wunused-function -I/home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/drivers/media/platform/tegra/ -I/home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/../nvidia/include/ -I/home/yy/camera_driver_build/nvidia/include -I/home/yy/camera_driver_build/nvlink/include -I/home/yy/camera_driver_build/nvgpu/include -I/home/yy/camera_driver_build/nvgpu-next/include -I/home/yy/camera_driver_build/nvidia-t239/include -I/home/yy/camera_driver_build/stereolabs/include -I/home/yy/camera_driver_build/cti/include  -DMODULE  -DKBUILD_BASENAME='"ecam_gmsl_octa_yuv_common"' -DKBUILD_MODNAME='"ecam_gmsl_yuv_common"' -c -o /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.o /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.c

source_/home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.o := /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.c

deps_/home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.o := \
    $(wildcard include/config/of.h) \
    $(wildcard include/config/media/controller.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kconfig.h \
    $(wildcard include/config/cc/version/text.h) \
    $(wildcard include/config/cpu/big/endian.h) \
    $(wildcard include/config/booger.h) \
    $(wildcard include/config/foo.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/compiler_types.h \
    $(wildcard include/config/have/arch/compiler/h.h) \
    $(wildcard include/config/enable/must/check.h) \
    $(wildcard include/config/cc/has/asm/inline.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/compiler_attributes.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/compiler-gcc.h \
    $(wildcard include/config/arm64.h) \
    $(wildcard include/config/retpoline.h) \
    $(wildcard include/config/arch/use/builtin/bswap.h) \
    $(wildcard include/config/kcov.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/compiler.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ktime.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/time.h \
    $(wildcard include/config/arch/uses/gettimeoffset.h) \
    $(wildcard include/config/posix/timers.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/cache.h \
    $(wildcard include/config/smp.h) \
    $(wildcard include/config/arch/has/cache/line/size.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/kernel.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/sysinfo.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/types.h \
    $(wildcard include/config/have/uid16.h) \
    $(wildcard include/config/uid16.h) \
    $(wildcard include/config/arch/dma/addr/t/64bit.h) \
    $(wildcard include/config/phys/addr/t/64bit.h) \
    $(wildcard include/config/64bit.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/types.h \
  arch/arm64/include/generated/uapi/asm/types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/int-ll64.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/int-ll64.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/bitsperlong.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitsperlong.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/bitsperlong.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/posix_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/stddef.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/stddef.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/compiler_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/posix_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/posix_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/const.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/vdso/const.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/const.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/cache.h \
    $(wildcard include/config/kasan/sw/tags.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/cputype.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/sysreg.h \
    $(wildcard include/config/broken/gas/inst.h) \
    $(wildcard include/config/arm64/pa/bits/52.h) \
    $(wildcard include/config/arm64/4k/pages.h) \
    $(wildcard include/config/arm64/16k/pages.h) \
    $(wildcard include/config/arm64/64k/pages.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bits.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/vdso/bits.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/build_bug.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/compiler.h \
    $(wildcard include/config/trace/branch/profiling.h) \
    $(wildcard include/config/profile/all/branches.h) \
    $(wildcard include/config/stack/validation.h) \
  arch/arm64/include/generated/asm/rwonce.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/rwonce.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kasan-checks.h \
    $(wildcard include/config/kasan.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kcsan-checks.h \
    $(wildcard include/config/kcsan.h) \
    $(wildcard include/config/kcsan/ignore/atomics.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/stringify.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/alternative.h \
    $(wildcard include/config/modules.h) \
    $(wildcard include/config/arm64/uao.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/cpucaps.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/insn.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/init.h \
    $(wildcard include/config/have/arch/prel32/relocations.h) \
    $(wildcard include/config/strict/kernel/rwx.h) \
    $(wildcard include/config/strict/module/rwx.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bitops.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/bitops.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/builtin-__ffs.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/builtin-ffs.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/builtin-__fls.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/builtin-fls.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/ffz.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/fls64.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/find.h \
    $(wildcard include/config/generic/find/first/bit.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/sched.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/hweight.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/arch_hweight.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/const_hweight.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/atomic.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/atomic.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/atomic.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/barrier.h \
    $(wildcard include/config/arm64/pseudo/nmi.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/barrier.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/cmpxchg.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/lse.h \
    $(wildcard include/config/arm64/lse/atomics.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/atomic_ll_sc.h \
    $(wildcard include/config/cc/has/k/constraint.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/export.h \
    $(wildcard include/config/modversions.h) \
    $(wildcard include/config/module/rel/crcs.h) \
    $(wildcard include/config/trim/unused/ksyms.h) \
    $(wildcard include/config/unused/symbols.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/jump_label.h \
    $(wildcard include/config/jump/label.h) \
    $(wildcard include/config/have/arch/jump/label/relative.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/jump_label.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/atomic_lse.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/atomic-arch-fallback.h \
    $(wildcard include/config/generic/atomic64.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/atomic-instrumented.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/instrumented.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/atomic-long.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/lock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/non-atomic.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/le.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/byteorder.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/byteorder/little_endian.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/byteorder/little_endian.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/swab.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/swab.h \
  arch/arm64/include/generated/uapi/asm/swab.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/swab.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/byteorder/generic.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/math64.h \
    $(wildcard include/config/arch/supports/int128.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/vdso/math64.h \
  arch/arm64/include/generated/asm/div64.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/div64.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/time64.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/vdso/time64.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/time.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/time_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/time32.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/timex.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/timex.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/param.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/param.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/param.h \
    $(wildcard include/config/hz.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/param.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/timex.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/arch_timer.h \
    $(wildcard include/config/arm/arch/timer/ool/workaround.h) \
    $(wildcard include/config/compat.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/hwcap.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/hwcap.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/cpufeature.h \
    $(wildcard include/config/arm64/sw/ttbr0/pan.h) \
    $(wildcard include/config/arm64/sve.h) \
    $(wildcard include/config/arm64/cnp.h) \
    $(wildcard include/config/arm64/ptr/auth.h) \
    $(wildcard include/config/arm64/mte.h) \
    $(wildcard include/config/arm64/debug/priority/masking.h) \
    $(wildcard include/config/arm64/bti.h) \
    $(wildcard include/config/arm64/tlb/range.h) \
    $(wildcard include/config/arm64/pa/bits.h) \
    $(wildcard include/config/arm64/hw/afdbm.h) \
    $(wildcard include/config/arm64/amu/extn.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bug.h \
    $(wildcard include/config/generic/bug.h) \
    $(wildcard include/config/bug/on/data/corruption.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/bug.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/asm-bug.h \
    $(wildcard include/config/debug/bugverbose.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/brk-imm.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/bug.h \
    $(wildcard include/config/bug.h) \
    $(wildcard include/config/generic/bug/relative/pointers.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/instrumentation.h \
    $(wildcard include/config/debug/entry.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kernel.h \
    $(wildcard include/config/preempt/voluntary.h) \
    $(wildcard include/config/debug/atomic/sleep.h) \
    $(wildcard include/config/preempt/rt.h) \
    $(wildcard include/config/mmu.h) \
    $(wildcard include/config/prove/locking.h) \
    $(wildcard include/config/panic/timeout.h) \
    $(wildcard include/config/tracing.h) \
    $(wildcard include/config/ftrace/mcount/record.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/limits.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/limits.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/vdso/limits.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/linkage.h \
    $(wildcard include/config/arch/use/sym/annotations.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/linkage.h \
    $(wildcard include/config/arm64/bti/kernel.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/log2.h \
    $(wildcard include/config/arch/has/ilog2/u32.h) \
    $(wildcard include/config/arch/has/ilog2/u64.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/minmax.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/typecheck.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/printk.h \
    $(wildcard include/config/message/loglevel/default.h) \
    $(wildcard include/config/console/loglevel/default.h) \
    $(wildcard include/config/console/loglevel/quiet.h) \
    $(wildcard include/config/early/printk.h) \
    $(wildcard include/config/printk/nmi.h) \
    $(wildcard include/config/printk.h) \
    $(wildcard include/config/dynamic/debug.h) \
    $(wildcard include/config/dynamic/debug/core.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kern_levels.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ratelimit_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/spinlock_types.h \
    $(wildcard include/config/debug/spinlock.h) \
    $(wildcard include/config/debug/lock/alloc.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/spinlock_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/nr/cpus.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/qrwlock_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/lockdep_types.h \
    $(wildcard include/config/prove/raw/lock/nesting.h) \
    $(wildcard include/config/preempt/lock.h) \
    $(wildcard include/config/lockdep.h) \
    $(wildcard include/config/lock/stat.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rwlock_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/smp.h \
    $(wildcard include/config/up/late/init.h) \
    $(wildcard include/config/debug/preempt.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/errno.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/errno.h \
  arch/arm64/include/generated/uapi/asm/errno.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/errno.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/errno-base.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/list.h \
    $(wildcard include/config/debug/list.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/poison.h \
    $(wildcard include/config/illegal/pointer/value.h) \
    $(wildcard include/config/page/poisoning/zero.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/cpumask.h \
    $(wildcard include/config/cpumask/offstack.h) \
    $(wildcard include/config/hotplug/cpu.h) \
    $(wildcard include/config/debug/per/cpu/maps.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/threads.h \
    $(wildcard include/config/base/small.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bitmap.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/string.h \
    $(wildcard include/config/binary/printf.h) \
    $(wildcard include/config/fortify/source.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/string.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/string.h \
    $(wildcard include/config/arch/has/uaccess/flushcache.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/smp_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/llist.h \
    $(wildcard include/config/arch/have/nmi/safe/cmpxchg.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/preempt.h \
    $(wildcard include/config/preempt/count.h) \
    $(wildcard include/config/trace/preempt/toggle.h) \
    $(wildcard include/config/preemption.h) \
    $(wildcard include/config/preempt/notifiers.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/preempt.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/thread_info.h \
    $(wildcard include/config/thread/info/in/task.h) \
    $(wildcard include/config/have/arch/within/stack/frames.h) \
    $(wildcard include/config/hardened/usercopy.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/restart_block.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/current.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/thread_info.h \
    $(wildcard include/config/shadow/call/stack.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/memory.h \
    $(wildcard include/config/arm64/va/bits.h) \
    $(wildcard include/config/kasan/shadow/offset.h) \
    $(wildcard include/config/vmap/stack.h) \
    $(wildcard include/config/debug/virtual.h) \
    $(wildcard include/config/sparsemem/vmemmap.h) \
    $(wildcard include/config/efi.h) \
    $(wildcard include/config/arm/gic/v3/its.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sizes.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/page-def.h \
    $(wildcard include/config/arm64/page/shift.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/mmdebug.h \
    $(wildcard include/config/debug/vm.h) \
    $(wildcard include/config/debug/vm/pgflags.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/memory_model.h \
    $(wildcard include/config/flatmem.h) \
    $(wildcard include/config/discontigmem.h) \
    $(wildcard include/config/sparsemem.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pfn.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/stack_pointer.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/smp.h \
    $(wildcard include/config/arm64/acpi/parking/protocol.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/percpu.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/percpu.h \
    $(wildcard include/config/have/setup/per/cpu/area.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/percpu-defs.h \
    $(wildcard include/config/debug/force/weak/per/cpu.h) \
    $(wildcard include/config/amd/mem/encrypt.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/clocksource/arm_arch_timer.h \
    $(wildcard include/config/arm/arch/timer.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/timecounter.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/timex.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/vdso/time32.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/vdso/time.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/jiffies.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/vdso/jiffies.h \
  include/generated/timeconst.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/vdso/ktime.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/timekeeping.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/timekeeping32.h \
  /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/device.h \
    $(wildcard include/config/debug/devres.h) \
    $(wildcard include/config/energy/model.h) \
    $(wildcard include/config/generic/msi/irq/domain.h) \
    $(wildcard include/config/pinctrl.h) \
    $(wildcard include/config/generic/msi/irq.h) \
    $(wildcard include/config/dma/ops.h) \
    $(wildcard include/config/dma/declare/coherent.h) \
    $(wildcard include/config/dma/cma.h) \
    $(wildcard include/config/numa.h) \
    $(wildcard include/config/arch/has/sync/dma/for/device.h) \
    $(wildcard include/config/arch/has/sync/dma/for/cpu.h) \
    $(wildcard include/config/arch/has/sync/dma/for/cpu/all.h) \
    $(wildcard include/config/dma/ops/bypass.h) \
    $(wildcard include/config/pm/sleep.h) \
    $(wildcard include/config/devtmpfs.h) \
    $(wildcard include/config/sysfs/deprecated.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/dev_printk.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ratelimit.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched.h \
    $(wildcard include/config/virt/cpu/accounting/native.h) \
    $(wildcard include/config/sched/info.h) \
    $(wildcard include/config/schedstats.h) \
    $(wildcard include/config/fair/group/sched.h) \
    $(wildcard include/config/rt/group/sched.h) \
    $(wildcard include/config/rt/mutexes.h) \
    $(wildcard include/config/uclamp/task.h) \
    $(wildcard include/config/uclamp/buckets/count.h) \
    $(wildcard include/config/cgroup/sched.h) \
    $(wildcard include/config/blk/dev/io/trace.h) \
    $(wildcard include/config/preempt/rcu.h) \
    $(wildcard include/config/tasks/rcu.h) \
    $(wildcard include/config/tasks/trace/rcu.h) \
    $(wildcard include/config/psi.h) \
    $(wildcard include/config/memcg.h) \
    $(wildcard include/config/compat/brk.h) \
    $(wildcard include/config/cgroups.h) \
    $(wildcard include/config/blk/cgroup.h) \
    $(wildcard include/config/stackprotector.h) \
    $(wildcard include/config/arch/has/scaled/cputime.h) \
    $(wildcard include/config/virt/cpu/accounting/gen.h) \
    $(wildcard include/config/no/hz/full.h) \
    $(wildcard include/config/posix/cputimers.h) \
    $(wildcard include/config/posix/cpu/timers/task/work.h) \
    $(wildcard include/config/keys.h) \
    $(wildcard include/config/sysvipc.h) \
    $(wildcard include/config/detect/hung/task.h) \
    $(wildcard include/config/io/uring.h) \
    $(wildcard include/config/audit.h) \
    $(wildcard include/config/auditsyscall.h) \
    $(wildcard include/config/debug/mutexes.h) \
    $(wildcard include/config/trace/irqflags.h) \
    $(wildcard include/config/ubsan.h) \
    $(wildcard include/config/ubsan/trap.h) \
    $(wildcard include/config/block.h) \
    $(wildcard include/config/compaction.h) \
    $(wildcard include/config/task/xacct.h) \
    $(wildcard include/config/cpusets.h) \
    $(wildcard include/config/x86/cpu/resctrl.h) \
    $(wildcard include/config/futex.h) \
    $(wildcard include/config/perf/events.h) \
    $(wildcard include/config/numa/balancing.h) \
    $(wildcard include/config/rseq.h) \
    $(wildcard include/config/task/delay/acct.h) \
    $(wildcard include/config/fault/injection.h) \
    $(wildcard include/config/latencytop.h) \
    $(wildcard include/config/kunit.h) \
    $(wildcard include/config/function/graph/tracer.h) \
    $(wildcard include/config/uprobes.h) \
    $(wildcard include/config/bcache.h) \
    $(wildcard include/config/livepatch.h) \
    $(wildcard include/config/security.h) \
    $(wildcard include/config/gcc/plugin/stackleak.h) \
    $(wildcard include/config/x86/mce.h) \
    $(wildcard include/config/arch/task/struct/on/stack.h) \
    $(wildcard include/config/debug/rseq.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/sched.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pid.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rculist.h \
    $(wildcard include/config/prove/rcu/list.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rcupdate.h \
    $(wildcard include/config/tiny/rcu.h) \
    $(wildcard include/config/tasks/rcu/generic.h) \
    $(wildcard include/config/rcu/stall/common.h) \
    $(wildcard include/config/rcu/nocb/cpu.h) \
    $(wildcard include/config/tasks/rude/rcu.h) \
    $(wildcard include/config/tree/rcu.h) \
    $(wildcard include/config/debug/objects/rcu/head.h) \
    $(wildcard include/config/prove/rcu.h) \
    $(wildcard include/config/rcu/boost.h) \
    $(wildcard include/config/arch/weak/release/acquire.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/irqflags.h \
    $(wildcard include/config/irqsoff/tracer.h) \
    $(wildcard include/config/preempt/tracer.h) \
    $(wildcard include/config/trace/irqflags/support.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/irqflags.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/ptrace.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/ptrace.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/sve_context.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bottom_half.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/lockdep.h \
    $(wildcard include/config/debug/locking/api/selftests.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/processor.h \
    $(wildcard include/config/kuser/helpers.h) \
    $(wildcard include/config/arm64/force/52bit.h) \
    $(wildcard include/config/have/hw/breakpoint.h) \
    $(wildcard include/config/arm64/tagged/addr/abi.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/vdso/processor.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/vdso/processor.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/hw_breakpoint.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/virt.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/sections.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/sections.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/kasan.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/pgtable-types.h \
    $(wildcard include/config/pgtable/levels.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/pgtable-nop4d.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/pgtable-hwdef.h \
    $(wildcard include/config/arm64/cont/pte/shift.h) \
    $(wildcard include/config/arm64/cont/pmd/shift.h) \
    $(wildcard include/config/arm64/va/bits/52.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/pointer_auth.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/random.h \
    $(wildcard include/config/arch/random.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/once.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/random.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/ioctl.h \
  arch/arm64/include/generated/uapi/asm/ioctl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/ioctl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/ioctl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/irqnr.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/irqnr.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/prandom.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/percpu.h \
    $(wildcard include/config/need/per/cpu/embed/first/chunk.h) \
    $(wildcard include/config/need/per/cpu/page/first/chunk.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/siphash.h \
    $(wildcard include/config/have/efficient/unaligned/access.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/archrandom.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/spectre.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/fpsimd.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/sigcontext.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rcutree.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/wait.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/spinlock.h \
  arch/arm64/include/generated/asm/mmiowb.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/mmiowb.h \
    $(wildcard include/config/mmiowb.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/spinlock.h \
  arch/arm64/include/generated/asm/qrwlock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/qrwlock.h \
  arch/arm64/include/generated/asm/qspinlock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/qspinlock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rwlock.h \
    $(wildcard include/config/preempt.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/inline/spin/lock.h) \
    $(wildcard include/config/inline/spin/lock/bh.h) \
    $(wildcard include/config/inline/spin/lock/irq.h) \
    $(wildcard include/config/inline/spin/lock/irqsave.h) \
    $(wildcard include/config/inline/spin/trylock.h) \
    $(wildcard include/config/inline/spin/trylock/bh.h) \
    $(wildcard include/config/uninline/spin/unlock.h) \
    $(wildcard include/config/inline/spin/unlock/bh.h) \
    $(wildcard include/config/inline/spin/unlock/irq.h) \
    $(wildcard include/config/inline/spin/unlock/irqrestore.h) \
    $(wildcard include/config/generic/lockbreak.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/inline/read/lock.h) \
    $(wildcard include/config/inline/write/lock.h) \
    $(wildcard include/config/inline/read/lock/bh.h) \
    $(wildcard include/config/inline/write/lock/bh.h) \
    $(wildcard include/config/inline/read/lock/irq.h) \
    $(wildcard include/config/inline/write/lock/irq.h) \
    $(wildcard include/config/inline/read/lock/irqsave.h) \
    $(wildcard include/config/inline/write/lock/irqsave.h) \
    $(wildcard include/config/inline/read/trylock.h) \
    $(wildcard include/config/inline/write/trylock.h) \
    $(wildcard include/config/inline/read/unlock.h) \
    $(wildcard include/config/inline/write/unlock.h) \
    $(wildcard include/config/inline/read/unlock/bh.h) \
    $(wildcard include/config/inline/write/unlock/bh.h) \
    $(wildcard include/config/inline/read/unlock/irq.h) \
    $(wildcard include/config/inline/write/unlock/irq.h) \
    $(wildcard include/config/inline/read/unlock/irqrestore.h) \
    $(wildcard include/config/inline/write/unlock/irqrestore.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/wait.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/refcount.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sem.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/sem.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ipc.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/uidgid.h \
    $(wildcard include/config/multiuser.h) \
    $(wildcard include/config/user/ns.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/highuid.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rhashtable-types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/mutex.h \
    $(wildcard include/config/mutex/spin/on/owner.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/osq_lock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/debug_locks.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/workqueue.h \
    $(wildcard include/config/debug/objects/work.h) \
    $(wildcard include/config/freezer.h) \
    $(wildcard include/config/sysfs.h) \
    $(wildcard include/config/wq/watchdog.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/timer.h \
    $(wildcard include/config/debug/objects/timers.h) \
    $(wildcard include/config/no/hz/common.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/debugobjects.h \
    $(wildcard include/config/debug/objects.h) \
    $(wildcard include/config/debug/objects/free.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/ipc.h \
  arch/arm64/include/generated/uapi/asm/ipcbuf.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/ipcbuf.h \
  arch/arm64/include/generated/uapi/asm/sembuf.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/sembuf.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/shm.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/page.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/personality.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/personality.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/getorder.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/shm.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/hugetlb_encode.h \
  arch/arm64/include/generated/uapi/asm/shmbuf.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/shmbuf.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/shmparam.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/shmparam.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kcov.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/kcov.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/plist.h \
    $(wildcard include/config/debug/plist.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/hrtimer.h \
    $(wildcard include/config/high/res/timers.h) \
    $(wildcard include/config/time/low/res.h) \
    $(wildcard include/config/timerfd.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/hrtimer_defs.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rbtree.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/seqlock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ww_mutex.h \
    $(wildcard include/config/debug/ww/mutex/slowpath.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/timerqueue.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/seccomp.h \
    $(wildcard include/config/seccomp.h) \
    $(wildcard include/config/have/arch/seccomp/filter.h) \
    $(wildcard include/config/seccomp/filter.h) \
    $(wildcard include/config/checkpoint/restore.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/seccomp.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/seccomp.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/unistd.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/unistd.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/unistd.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/seccomp.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/unistd.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/nodemask.h \
    $(wildcard include/config/highmem.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/numa.h \
    $(wildcard include/config/nodes/shift.h) \
    $(wildcard include/config/numa/keep/meminfo.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/resource.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/resource.h \
  arch/arm64/include/generated/uapi/asm/resource.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/resource.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/resource.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/latencytop.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/prio.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/signal_types.h \
    $(wildcard include/config/old/sigaction.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/signal.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/signal.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/signal.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/signal.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/signal-defs.h \
  arch/arm64/include/generated/uapi/asm/siginfo.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/siginfo.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/mm_types_task.h \
    $(wildcard include/config/arch/want/batched/unmap/tlb/flush.h) \
    $(wildcard include/config/split/ptlock/cpus.h) \
    $(wildcard include/config/arch/enable/split/pmd/ptlock.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/task_io_accounting.h \
    $(wildcard include/config/task/io/accounting.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/posix-timers.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/alarmtimer.h \
    $(wildcard include/config/rtc/class.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/task_work.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/rseq.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kcsan.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/energy_model.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kobject.h \
    $(wildcard include/config/uevent/helper.h) \
    $(wildcard include/config/debug/kobject/release.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sysfs.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kernfs.h \
    $(wildcard include/config/kernfs.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/err.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/idr.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/radix-tree.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/xarray.h \
    $(wildcard include/config/xarray/multi.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/gfp.h \
    $(wildcard include/config/zone/dma.h) \
    $(wildcard include/config/zone/dma32.h) \
    $(wildcard include/config/zone/device.h) \
    $(wildcard include/config/contig/alloc.h) \
    $(wildcard include/config/cma.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/mmzone.h \
    $(wildcard include/config/force/max/zoneorder.h) \
    $(wildcard include/config/memory/isolation.h) \
    $(wildcard include/config/zsmalloc.h) \
    $(wildcard include/config/need/multiple/nodes.h) \
    $(wildcard include/config/memory/hotplug.h) \
    $(wildcard include/config/transparent/hugepage.h) \
    $(wildcard include/config/flat/node/mem/map.h) \
    $(wildcard include/config/page/extension.h) \
    $(wildcard include/config/deferred/struct/page/init.h) \
    $(wildcard include/config/have/memoryless/nodes.h) \
    $(wildcard include/config/sparsemem/extreme.h) \
    $(wildcard include/config/memory/hotremove.h) \
    $(wildcard include/config/have/arch/pfn/valid.h) \
    $(wildcard include/config/holes/in/zone.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pageblock-flags.h \
    $(wildcard include/config/hugetlb/page.h) \
    $(wildcard include/config/hugetlb/page/size/variable.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/page-flags-layout.h \
  include/generated/bounds.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/sparsemem.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/mm_types.h \
    $(wildcard include/config/have/aligned/struct/page.h) \
    $(wildcard include/config/userfaultfd.h) \
    $(wildcard include/config/swap.h) \
    $(wildcard include/config/have/arch/compat/mmap/bases.h) \
    $(wildcard include/config/membarrier.h) \
    $(wildcard include/config/aio.h) \
    $(wildcard include/config/mmu/notifier.h) \
    $(wildcard include/config/iommu/support.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/auxvec.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/auxvec.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/auxvec.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rwsem.h \
    $(wildcard include/config/rwsem/spin/on/owner.h) \
    $(wildcard include/config/debug/rwsems.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/completion.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/swait.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/uprobes.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/mmu.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/page-flags.h \
    $(wildcard include/config/arch/uses/pg/uncached.h) \
    $(wildcard include/config/memory/failure.h) \
    $(wildcard include/config/idle/page/tracking.h) \
    $(wildcard include/config/thp/swap.h) \
    $(wildcard include/config/ksm.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/memory_hotplug.h \
    $(wildcard include/config/arch/has/add/pages.h) \
    $(wildcard include/config/have/arch/nodedata/extension.h) \
    $(wildcard include/config/have/bootmem/info/node.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/notifier.h \
    $(wildcard include/config/tree/srcu.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/srcu.h \
    $(wildcard include/config/tiny/srcu.h) \
    $(wildcard include/config/srcu.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rcu_segcblist.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/srcutree.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rcu_node_tree.h \
    $(wildcard include/config/rcu/fanout.h) \
    $(wildcard include/config/rcu/fanout/leaf.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/topology.h \
    $(wildcard include/config/use/percpu/numa/node/id.h) \
    $(wildcard include/config/sched/smt.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/arch_topology.h \
    $(wildcard include/config/generic/arch/topology.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/topology.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/topology.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kconfig.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/local_lock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/local_lock_internal.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kobject_ns.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/stat.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/stat.h \
  arch/arm64/include/generated/uapi/asm/stat.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/stat.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/compat.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/compat.h \
    $(wildcard include/config/compat/for/u64/alignment.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/task_stack.h \
    $(wildcard include/config/stack/growsup.h) \
    $(wildcard include/config/debug/stack/usage.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/magic.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/stat.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kref.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/cpufreq.h \
    $(wildcard include/config/cpu/freq.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/topology.h \
    $(wildcard include/config/sched/debug.h) \
    $(wildcard include/config/sched/mc.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/idle.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/sd_flags.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ioport.h \
    $(wildcard include/config/io/strict/devmem.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/klist.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pm.h \
    $(wildcard include/config/vt/console/sleep.h) \
    $(wildcard include/config/pm.h) \
    $(wildcard include/config/pm/clk.h) \
    $(wildcard include/config/pm/generic/domains.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/overflow.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/device/bus.h \
    $(wildcard include/config/acpi.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/device/class.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/device/driver.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/device.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pm_wakeup.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/module.h \
    $(wildcard include/config/modules/tree/lookup.h) \
    $(wildcard include/config/module/sig.h) \
    $(wildcard include/config/kallsyms.h) \
    $(wildcard include/config/tracepoints.h) \
    $(wildcard include/config/bpf/events.h) \
    $(wildcard include/config/event/tracing.h) \
    $(wildcard include/config/kprobes.h) \
    $(wildcard include/config/have/static/call/inline.h) \
    $(wildcard include/config/module/unload.h) \
    $(wildcard include/config/constructors.h) \
    $(wildcard include/config/function/error/injection.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kmod.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/umh.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sysctl.h \
    $(wildcard include/config/sysctl.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/sysctl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/elf.h \
    $(wildcard include/config/arch/use/gnu/property.h) \
    $(wildcard include/config/arch/have/elf/prot.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/elf.h \
    $(wildcard include/config/compat/vdso.h) \
  arch/arm64/include/generated/asm/user.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/user.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/elf.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/elf-em.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/fs.h \
    $(wildcard include/config/read/only/thp/for/fs.h) \
    $(wildcard include/config/fs/posix/acl.h) \
    $(wildcard include/config/cgroup/writeback.h) \
    $(wildcard include/config/ima.h) \
    $(wildcard include/config/file/locking.h) \
    $(wildcard include/config/fsnotify.h) \
    $(wildcard include/config/fs/encryption.h) \
    $(wildcard include/config/fs/verity.h) \
    $(wildcard include/config/epoll.h) \
    $(wildcard include/config/unicode.h) \
    $(wildcard include/config/quota.h) \
    $(wildcard include/config/fs/dax.h) \
    $(wildcard include/config/mandatory/file/locking.h) \
    $(wildcard include/config/migration.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/wait_bit.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kdev_t.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/kdev_t.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/dcache.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rculist_bl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/list_bl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bit_spinlock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/lockref.h \
    $(wildcard include/config/arch/use/cmpxchg/lockref.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/stringhash.h \
    $(wildcard include/config/dcache/word/access.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/hash.h \
    $(wildcard include/config/have/arch/hash.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/path.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/list_lru.h \
    $(wildcard include/config/memcg/kmem.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/shrinker.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/capability.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/capability.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/semaphore.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/fcntl.h \
    $(wildcard include/config/arch/32bit/off/t.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/fcntl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/uapi/asm/fcntl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/fcntl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/openat2.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/migrate_mode.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/percpu-rwsem.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rcuwait.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/signal.h \
    $(wildcard include/config/sched/autogroup.h) \
    $(wildcard include/config/bsd/process/acct.h) \
    $(wildcard include/config/taskstats.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/signal.h \
    $(wildcard include/config/proc/fs.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/jobctl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/task.h \
    $(wildcard include/config/have/exit/thread.h) \
    $(wildcard include/config/arch/wants/dynamic/task/struct.h) \
    $(wildcard include/config/have/arch/thread/struct/whitelist.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/uaccess.h \
    $(wildcard include/config/set/fs.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/fault-inject-usercopy.h \
    $(wildcard include/config/fault/injection/usercopy.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/uaccess.h \
    $(wildcard include/config/arm64/pan.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/kernel-pgtable.h \
    $(wildcard include/config/randomize/base.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/extable.h \
    $(wildcard include/config/bpf/jit.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/cred.h \
    $(wildcard include/config/debug/credentials.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/key.h \
    $(wildcard include/config/key/notifications.h) \
    $(wildcard include/config/net.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/assoc_array.h \
    $(wildcard include/config/associative/array.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/user.h \
    $(wildcard include/config/fanotify.h) \
    $(wildcard include/config/posix/mqueue.h) \
    $(wildcard include/config/bpf/syscall.h) \
    $(wildcard include/config/watch/queue.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rcu_sync.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/delayed_call.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/uuid.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/uuid.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/errseq.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ioprio.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/rt.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/iocontext.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/fs_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/fs.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/quota.h \
    $(wildcard include/config/quota/netlink/interface.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/percpu_counter.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/dqblk_xfs.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/dqblk_v1.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/dqblk_v2.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/dqblk_qtree.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/projid.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/quota.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/nfs_fs_i.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/moduleparam.h \
    $(wildcard include/config/alpha.h) \
    $(wildcard include/config/ia64.h) \
    $(wildcard include/config/ppc64.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rbtree_latch.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/error-injection.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/error-injection.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/tracepoint-defs.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/static_key.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/static_call_types.h \
    $(wildcard include/config/have/static/call.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/module.h \
    $(wildcard include/config/arm64/module/plts.h) \
    $(wildcard include/config/dynamic/ftrace.h) \
    $(wildcard include/config/arm64/erratum/843419.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/module.h \
    $(wildcard include/config/have/mod/arch/specific.h) \
    $(wildcard include/config/modules/use/elf/rel.h) \
    $(wildcard include/config/modules/use/elf/rela.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/i2c.h \
    $(wildcard include/config/i2c.h) \
    $(wildcard include/config/i2c/slave.h) \
    $(wildcard include/config/i2c/boardinfo.h) \
    $(wildcard include/config/i2c/mux.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/acpi.h \
    $(wildcard include/config/acpi/debugger.h) \
    $(wildcard include/config/x86.h) \
    $(wildcard include/config/acpi/processor/cstate.h) \
    $(wildcard include/config/acpi/hotplug/cpu.h) \
    $(wildcard include/config/acpi/hotplug/ioapic.h) \
    $(wildcard include/config/x86/io/apic.h) \
    $(wildcard include/config/pci.h) \
    $(wildcard include/config/acpi/wmi.h) \
    $(wildcard include/config/acpi/numa.h) \
    $(wildcard include/config/hibernation.h) \
    $(wildcard include/config/acpi/hotplug/memory.h) \
    $(wildcard include/config/acpi/container.h) \
    $(wildcard include/config/acpi/gtdt.h) \
    $(wildcard include/config/gpiolib.h) \
    $(wildcard include/config/acpi/table/upgrade.h) \
    $(wildcard include/config/acpi/watchdog.h) \
    $(wildcard include/config/acpi/spcr/table.h) \
    $(wildcard include/config/acpi/generic/gsi.h) \
    $(wildcard include/config/acpi/lpit.h) \
    $(wildcard include/config/acpi/pptt.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/irqdomain.h \
    $(wildcard include/config/irq/domain/hierarchy.h) \
    $(wildcard include/config/generic/irq/debugfs.h) \
    $(wildcard include/config/irq/domain.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/irqhandler.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/of.h \
    $(wildcard include/config/of/dynamic.h) \
    $(wildcard include/config/sparc.h) \
    $(wildcard include/config/of/promtree.h) \
    $(wildcard include/config/of/kobj.h) \
    $(wildcard include/config/of/numa.h) \
    $(wildcard include/config/of/overlay.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/mod_devicetable.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/property.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/fwnode.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/resource_ext.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/slab.h \
    $(wildcard include/config/debug/slab.h) \
    $(wildcard include/config/failslab.h) \
    $(wildcard include/config/have/hardened/usercopy/allocator.h) \
    $(wildcard include/config/slab.h) \
    $(wildcard include/config/slub.h) \
    $(wildcard include/config/slob.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/percpu-refcount.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kasan.h \
    $(wildcard include/config/kasan/vmalloc.h) \
    $(wildcard include/config/kasan/generic.h) \
    $(wildcard include/config/kasan/inline.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acpi.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/platform/acenv.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/platform/acgcc.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/platform/aclinux.h \
    $(wildcard include/config/acpi/reduced/hardware/only.h) \
    $(wildcard include/config/acpi/debug.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ctype.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/acenv.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acnames.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/actypes.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acexcep.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/actbl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/actbl1.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/actbl2.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/actbl3.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acrestyp.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/platform/acenvex.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/platform/aclinuxex.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/platform/acgccex.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acoutput.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acpiosxf.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acpixf.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acconfig.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acbuffer.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/dynamic_debug.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acpi_bus.h \
    $(wildcard include/config/acpi/system/power/states/support.h) \
    $(wildcard include/config/acpi/sleep.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acpi_drivers.h \
    $(wildcard include/config/acpi/dock.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acpi_numa.h \
    $(wildcard include/config/acpi/hmat.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/acpi/acpi_io.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/io.h \
    $(wildcard include/config/have/arch/huge/vmap.h) \
    $(wildcard include/config/has/ioport/map.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/io.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pgtable.h \
    $(wildcard include/config/highpte.h) \
    $(wildcard include/config/have/arch/transparent/hugepage/pud.h) \
    $(wildcard include/config/have/arch/soft/dirty.h) \
    $(wildcard include/config/arch/enable/thp/migration.h) \
    $(wildcard include/config/arch/has/pte/devmap.h) \
    $(wildcard include/config/x86/espfix64.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/pgtable.h \
    $(wildcard include/config/arm64/non/shared/tlbi.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/proc-fns.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/mte.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/pgtable-prot.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/tlbflush.h \
    $(wildcard include/config/arm64/workaround/repeat/tlbi.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bitfield.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/fixmap.h \
    $(wildcard include/config/acpi/apei/ghes.h) \
    $(wildcard include/config/arm/sde/interface.h) \
    $(wildcard include/config/unmap/kernel/at/el0.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/boot.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/fixmap.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/pgtable_uffd.h \
    $(wildcard include/config/have/arch/userfaultfd/wp.h) \
  arch/arm64/include/generated/asm/early_ioremap.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/early_ioremap.h \
    $(wildcard include/config/generic/early/ioremap.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/io.h \
    $(wildcard include/config/generic/iomap.h) \
    $(wildcard include/config/generic/ioremap.h) \
    $(wildcard include/config/virt/to/bus.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/pci_iomap.h \
    $(wildcard include/config/no/generic/pci/ioport/map.h) \
    $(wildcard include/config/generic/pci/iomap.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/logic_pio.h \
    $(wildcard include/config/indirect/pio.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/vmalloc.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/vmalloc.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/acpi.h \
    $(wildcard include/config/acpi/apei.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/efi.h \
    $(wildcard include/config/x86/64.h) \
    $(wildcard include/config/x86/32.h) \
    $(wildcard include/config/efi/esrt.h) \
    $(wildcard include/config/efi/fake/memmap.h) \
    $(wildcard include/config/efi/pcdp.h) \
    $(wildcard include/config/efi/soft/reserve.h) \
    $(wildcard include/config/efi/runtime/map.h) \
    $(wildcard include/config/reset/attack/mitigation.h) \
    $(wildcard include/config/efi/embedded/firmware.h) \
    $(wildcard include/config/load/uefi/keys.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/proc_fs.h \
    $(wildcard include/config/proc/pid/arch/status.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rtc.h \
    $(wildcard include/config/rtc/intf/dev/uie/emul.h) \
    $(wildcard include/config/rtc/hctosys/device.h) \
    $(wildcard include/config/rtc/nvmem.h) \
    $(wildcard include/config/rtc/intf/sysfs.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/interrupt.h \
    $(wildcard include/config/irq/forced/threading.h) \
    $(wildcard include/config/generic/irq/probe.h) \
    $(wildcard include/config/irq/timings.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/irqreturn.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/hardirq.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/context_tracking_state.h \
    $(wildcard include/config/context/tracking.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ftrace_irq.h \
    $(wildcard include/config/hwlat/tracer.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/vtime.h \
    $(wildcard include/config/virt/cpu/accounting.h) \
    $(wildcard include/config/irq/time/accounting.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/hardirq.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/irq.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/irq.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/kvm_arm.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/esr.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/irq_cpustat.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/nvmem-provider.h \
    $(wildcard include/config/nvmem.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/gpio/consumer.h \
    $(wildcard include/config/of/gpio.h) \
    $(wildcard include/config/gpio/sysfs.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/rtc.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/seq_file.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/cdev.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/poll.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/poll.h \
  arch/arm64/include/generated/uapi/asm/poll.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/poll.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/eventpoll.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pstore.h \
    $(wildcard include/config/pstore/rtrace.h) \
    $(wildcard include/config/arm/thumb.h) \
    $(wildcard include/config/arm.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kmsg_dump.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/range.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/reboot.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/reboot.h \
  arch/arm64/include/generated/asm/emergency-restart.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/emergency-restart.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/screen_info.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/screen_info.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/memblock.h \
    $(wildcard include/config/arch/keep/memblock.h) \
    $(wildcard include/config/have/memblock/phys/map.h) \
    $(wildcard include/config/memtest.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/mm.h \
    $(wildcard include/config/have/arch/mmap/rnd/bits.h) \
    $(wildcard include/config/have/arch/mmap/rnd/compat/bits.h) \
    $(wildcard include/config/mem/soft/dirty.h) \
    $(wildcard include/config/arch/uses/high/vma/flags.h) \
    $(wildcard include/config/arch/has/pkeys.h) \
    $(wildcard include/config/ppc.h) \
    $(wildcard include/config/parisc.h) \
    $(wildcard include/config/sparc64.h) \
    $(wildcard include/config/shmem.h) \
    $(wildcard include/config/dev/pagemap/ops.h) \
    $(wildcard include/config/device/private.h) \
    $(wildcard include/config/pci/p2pdma.h) \
    $(wildcard include/config/arch/has/pte/special.h) \
    $(wildcard include/config/debug/vm/rb.h) \
    $(wildcard include/config/page/poisoning.h) \
    $(wildcard include/config/init/on/alloc/default/on.h) \
    $(wildcard include/config/init/on/free/default/on.h) \
    $(wildcard include/config/debug/pagealloc.h) \
    $(wildcard include/config/arch/has/set/direct/map.h) \
    $(wildcard include/config/hugetlbfs.h) \
    $(wildcard include/config/mapping/dirty/helpers.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/mmap_lock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/page_ext.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/stacktrace.h \
    $(wildcard include/config/stacktrace.h) \
    $(wildcard include/config/arch/stackwalk.h) \
    $(wildcard include/config/have/reliable/stacktrace.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/stackdepot.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/page_ref.h \
    $(wildcard include/config/debug/page/ref.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/memremap.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/huge_mm.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/coredump.h \
    $(wildcard include/config/core/dump/default/elf/headers.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/vmstat.h \
    $(wildcard include/config/vm/event/counters.h) \
    $(wildcard include/config/debug/tlbflush.h) \
    $(wildcard include/config/debug/vm/vmacache.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/vm_event_item.h \
    $(wildcard include/config/memory/balloon.h) \
    $(wildcard include/config/balloon/compaction.h) \
  arch/arm64/include/generated/asm/dma.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/dma.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/psci.h \
    $(wildcard include/config/arm/psci/fw.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/arm-smccc.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/smp_plat.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/rtmutex.h \
    $(wildcard include/config/debug/rt/mutexes.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/i2c.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/of_device.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/cpu.h \
    $(wildcard include/config/pm/sleep/smp.h) \
    $(wildcard include/config/pm/sleep/smp/nonzero/cpu.h) \
    $(wildcard include/config/hotplug/smt.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/node.h \
    $(wildcard include/config/hmem/reporting.h) \
    $(wildcard include/config/memory/hotplug/sparse.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/cpuhotplug.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/platform_device.h \
    $(wildcard include/config/suspend.h) \
    $(wildcard include/config/hibernate/callbacks.h) \
    $(wildcard include/config/superh.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/of_platform.h \
    $(wildcard include/config/of/address.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/../nvidia/include/media/camera_common.h \
    $(wildcard include/config/video/ecam/isp/multicam.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/clk.h \
    $(wildcard include/config/common/clk.h) \
    $(wildcard include/config/have/clk/prepare.h) \
    $(wildcard include/config/have/clk.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/debugfs.h \
    $(wildcard include/config/debug/fs.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/delay.h \
  arch/arm64/include/generated/asm/delay.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/delay.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/regmap.h \
    $(wildcard include/config/regmap.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/iopoll.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/regulator/consumer.h \
    $(wildcard include/config/regulator.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/suspend.h \
    $(wildcard include/config/vt.h) \
    $(wildcard include/config/hibernation/snapshot/dev.h) \
    $(wildcard include/config/pm/sleep/debug.h) \
    $(wildcard include/config/pm/autosleep.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/swap.h \
    $(wildcard include/config/frontswap.h) \
    $(wildcard include/config/memcg/swap.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/memcontrol.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/cgroup.h \
    $(wildcard include/config/cgroup/cpuacct.h) \
    $(wildcard include/config/sock/cgroup/data.h) \
    $(wildcard include/config/cgroup/net/prio.h) \
    $(wildcard include/config/cgroup/net/classid.h) \
    $(wildcard include/config/cgroup/data.h) \
    $(wildcard include/config/cgroup/bpf.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/cgroupstats.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/taskstats.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ns_common.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/nsproxy.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/user_namespace.h \
    $(wildcard include/config/inotify/user.h) \
    $(wildcard include/config/persistent/keyrings.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kernel_stat.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/cgroup-defs.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/u64_stats_sync.h \
  arch/arm64/include/generated/asm/local64.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/local64.h \
  arch/arm64/include/generated/asm/local.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/local.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bpf-cgroup.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bpf.h \
    $(wildcard include/config/bpf/jit/always/on.h) \
    $(wildcard include/config/bpf/stream/parser.h) \
    $(wildcard include/config/inet.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/bpf.h \
    $(wildcard include/config/efficient/unaligned/access.h) \
    $(wildcard include/config/ip/route/classid.h) \
    $(wildcard include/config/bpf/kprobe/override.h) \
    $(wildcard include/config/xfrm.h) \
    $(wildcard include/config/bpf/lirc/mode2.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/bpf_common.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/file.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kallsyms.h \
    $(wildcard include/config/kallsyms/all.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bpf_types.h \
    $(wildcard include/config/bpf/lsm.h) \
    $(wildcard include/config/xdp/sockets.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/psi_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kthread.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/cgroup_subsys.h \
    $(wildcard include/config/cgroup/device.h) \
    $(wildcard include/config/cgroup/freezer.h) \
    $(wildcard include/config/cgroup/perf.h) \
    $(wildcard include/config/cgroup/hugetlb.h) \
    $(wildcard include/config/cgroup/pids.h) \
    $(wildcard include/config/cgroup/rdma.h) \
    $(wildcard include/config/cgroup/debug.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/page_counter.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/vmpressure.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/eventfd.h \
    $(wildcard include/config/eventfd.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/writeback.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/flex_proportions.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/backing-dev-defs.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/blk_types.h \
    $(wildcard include/config/blk/cgroup/iocost.h) \
    $(wildcard include/config/blk/inline/encryption.h) \
    $(wildcard include/config/blk/dev/integrity.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bvec.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/blk-cgroup.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/blkdev.h \
    $(wildcard include/config/blk/rq/alloc/time.h) \
    $(wildcard include/config/blk/wbt.h) \
    $(wildcard include/config/blk/dev/zoned.h) \
    $(wildcard include/config/blk/dev/bsg.h) \
    $(wildcard include/config/blk/dev/throttling.h) \
    $(wildcard include/config/blk/debug/fs.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sched/clock.h \
    $(wildcard include/config/have/unstable/sched/clock.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/major.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/genhd.h \
    $(wildcard include/config/fail/make/request.h) \
    $(wildcard include/config/cdrom.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pagemap.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/highmem.h \
    $(wildcard include/config/debug/highmem.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/cacheflush.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kgdb.h \
    $(wildcard include/config/have/arch/kgdb.h) \
    $(wildcard include/config/kgdb.h) \
    $(wildcard include/config/serial/kgdb/nmi.h) \
    $(wildcard include/config/kgdb/honour/blocklist.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/kprobes.h \
    $(wildcard include/config/kretprobes.h) \
    $(wildcard include/config/kprobes/sanity/test.h) \
    $(wildcard include/config/optprobes.h) \
    $(wildcard include/config/kprobes/on/ftrace.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ftrace.h \
    $(wildcard include/config/function/tracer.h) \
    $(wildcard include/config/dynamic/ftrace/with/regs.h) \
    $(wildcard include/config/dynamic/ftrace/with/direct/calls.h) \
    $(wildcard include/config/have/dynamic/ftrace/with/direct/calls.h) \
    $(wildcard include/config/stack/tracer.h) \
    $(wildcard include/config/frame/pointer.h) \
    $(wildcard include/config/function/profiler.h) \
    $(wildcard include/config/ftrace/syscalls.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/trace_clock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/trace_clock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ptrace.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pid_namespace.h \
    $(wildcard include/config/pid/ns.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/ptrace.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/ftrace.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/compat.h \
    $(wildcard include/config/arch/has/syscall/wrapper.h) \
    $(wildcard include/config/x86/x32/abi.h) \
    $(wildcard include/config/compat/old/sigaction.h) \
    $(wildcard include/config/odd/rt/sigaction.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/socket.h \
  arch/arm64/include/generated/uapi/asm/socket.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/socket.h \
  arch/arm64/include/generated/uapi/asm/sockios.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/asm-generic/sockios.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/sockios.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/uio.h \
    $(wildcard include/config/arch/has/copy/mc.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/uio.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/socket.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/if.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/libc-compat.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/hdlc/ioctl.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/aio_abi.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/syscall_wrapper.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/kprobes.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/kprobes.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/kgdb.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/arch/arm64/include/asm/debug-monitors.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/cacheflush.h \
  arch/arm64/include/generated/asm/kmap_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/asm-generic/kmap_types.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/hugetlb_inline.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/mempool.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bio.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/bsg.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/bsg.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/scatterlist.h \
    $(wildcard include/config/need/sg/dma/length.h) \
    $(wildcard include/config/debug/sg.h) \
    $(wildcard include/config/sgl/alloc.h) \
    $(wildcard include/config/arch/no/sg/chain.h) \
    $(wildcard include/config/sg/pool.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/blkzoned.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/elevator.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/hashtable.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/blk-mq.h \
    $(wildcard include/config/fail/io/timeout.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/sbitmap.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/freezer.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/v4l2-mediabus.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/media-bus-format.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/videodev2.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/videodev2.h \
    $(wildcard include/config/video/adv/debug.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/v4l2-common.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/v4l2-controls.h \
  include/generated/uapi/linux/version.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/../nvidia/include/media/camera_version_utils.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/v4l2-device.h \
    $(wildcard include/config/video/v4l2/subdev/api.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/media-device.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/media-devnode.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/media-entity.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/media.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/v4l2-subdev.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/v4l2-subdev.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/v4l2-async.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/v4l2-common.h \
    $(wildcard include/config/video/v4l2/i2c.h) \
    $(wildcard include/config/spi.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/v4l2-dev.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/spi/spi.h \
    $(wildcard include/config/spi/slave.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/ptp_clock_kernel.h \
    $(wildcard include/config/ptp/1588/clock.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pps_kernel.h \
    $(wildcard include/config/ntp/pps.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/pps.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/uapi/linux/ptp_clock.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/v4l2-fh.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/v4l2-mediabus.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/v4l2-ctrls.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/media-request.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/mpeg2-ctrls.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/fwht-ctrls.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/h264-ctrls.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/vp8-ctrls.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/hevc-ctrls.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/videobuf2-dma-contig.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/videobuf2-v4l2.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/videobuf2-core.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/dma-buf.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/dma-mapping.h \
    $(wildcard include/config/dma/api/debug.h) \
    $(wildcard include/config/has/dma.h) \
    $(wildcard include/config/need/dma/map/state.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/dma-direction.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/mem_encrypt.h \
    $(wildcard include/config/arch/has/mem/encrypt.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/dma-fence.h \
    $(wildcard include/config/dma/fence/trace.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/media/v4l2-dv-timings.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/../nvidia/include/media/nvc_focus.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/../nvidia/include/media/sensor_common.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/../nvidia/include/media/tegra-v4l2-camera.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/../nvidia/include/uapi/media/camera_device.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/../nvidia/include/media/tegracam_core.h \
    $(wildcard include/config/video/ecam/isp.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/../nvidia/include/media/gmsl-link.h \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/firmware.h \
    $(wildcard include/config/fw/loader.h) \
  /home/yy/camera_driver_build/kernel_sources/sources/kernel/kernel-5.10/include/linux/pwm.h \
    $(wildcard include/config/pwm.h) \
    $(wildcard include/config/pwm/sysfs.h) \
  /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/cam_common.h \
  /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/serdes.h \
  /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/serdes_common.h \
  /home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/mcu_firmware.h \

/home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.o: $(deps_/home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.o)

$(deps_/home/yy/camera_driver_build/kernel_sources/STURDeCAM88_CUOAGX/ecam_gmsl_octa_yuv_common.o):
