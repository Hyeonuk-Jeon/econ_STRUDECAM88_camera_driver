#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x8044d9a7, "module_layout" },
	{ 0x3c6606fd, "kobject_put" },
	{ 0x2c76de84, "kmalloc_caches" },
	{ 0xaa77db49, "camera_common_s_power" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xe0db5371, "v4l2_async_register_subdev" },
	{ 0xf9a482f9, "msleep" },
	{ 0x1fdc7df2, "_mcount" },
	{ 0x304daf70, "tegra_media_entity_init" },
	{ 0xf5b20b56, "devm_pwm_get" },
	{ 0x98cf60b3, "strlen" },
	{ 0xf1f78552, "i2c_del_driver" },
	{ 0x84ac2c0b, "of_parse_phandle" },
	{ 0xe87f6182, "econ_err_hand_q" },
	{ 0xb092ac2e, "camera_common_parse_clocks" },
	{ 0x5b1921f0, "econ_num_uncorr_err" },
	{ 0xc6775d5f, "pwm_apply_state" },
	{ 0xff0dc18f, "camera_common_g_fmt" },
	{ 0x353b9642, "i2c_transfer" },
	{ 0x353017f0, "v4l2_ctrl_handler_free" },
	{ 0x192190e6, "econ_frame_err_track" },
	{ 0x2407aa68, "v4l2_ctrl_new_std" },
	{ 0xb43f9365, "ktime_get" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0xa1d6f1a9, "param_ops_bool" },
	{ 0x409bcb62, "mutex_unlock" },
	{ 0x85df9b6c, "strsep" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x92d7ca3a, "econ_dev_name" },
	{ 0x5bb5e84c, "kthread_create_on_node" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x82d92bba, "kobject_create_and_add" },
	{ 0xff963c53, "camera_common_try_fmt" },
	{ 0xf8a4741c, "sensor_common_parse_num_modes" },
	{ 0x451e457e, "camera_common_find_datafmt" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0xec8ccd3a, "v4l2_ctrl_new_std_menu" },
	{ 0xdcb764ad, "memset" },
	{ 0x977f511b, "__mutex_init" },
	{ 0xc5850110, "printk" },
	{ 0x3eabf18e, "kthread_stop" },
	{ 0xdc05730d, "of_find_property" },
	{ 0x6611fd1b, "of_property_read_string" },
	{ 0x9166fada, "strncpy" },
	{ 0x2ab7989d, "mutex_lock" },
	{ 0x967d2c25, "v4l2_ctrl_new_custom" },
	{ 0xa03cecda, "_dev_err" },
	{ 0x2015ad29, "devm_kfree" },
	{ 0xd1cecb1a, "camera_common_remove_debugfs" },
	{ 0xdbeea5a5, "of_match_device" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0xe3edb020, "v4l2_subdev_link_validate" },
	{ 0x88435c38, "i2c_register_driver" },
	{ 0xe94e6ec5, "module_put" },
	{ 0x795ee27e, "_dev_info" },
	{ 0xa916b694, "strnlen" },
	{ 0x12a38747, "usleep_range" },
	{ 0x86332725, "__stack_chk_fail" },
	{ 0x3a3947e6, "camera_common_s_fmt" },
	{ 0x1000e51, "schedule" },
	{ 0x2396c7f0, "clk_set_parent" },
	{ 0xa6f6263a, "camera_common_regulator_get" },
	{ 0x6c6e49f0, "wake_up_process" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x31c9253f, "devm_clk_get" },
	{ 0xce283e35, "kmem_cache_alloc_trace" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xe1f33ef8, "kernel_kobj" },
	{ 0x37a0cba, "kfree" },
	{ 0x4829a47e, "memcpy" },
	{ 0x54d16c8a, "camera_common_enum_frameintervals" },
	{ 0xaf657c7b, "v4l2_ctrl_handler_init_class" },
	{ 0x93909bad, "request_firmware" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x649cd91e, "v4l2_async_unregister_subdev" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x169a4424, "camera_common_initialize" },
	{ 0x4dddc25b, "sysfs_create_file_ns" },
	{ 0x9d0a8a9, "of_property_read_variable_u32_array" },
	{ 0x7ea70941, "devm_kmalloc" },
	{ 0x11bda3d4, "camera_common_enum_framesizes" },
	{ 0xc6d09aa9, "release_firmware" },
	{ 0x837d1aae, "try_module_get" },
	{ 0xc0903ab9, "v4l2_i2c_subdev_init" },
	{ 0xe914e41e, "strcpy" },
	{ 0xfacaf008, "camera_common_enum_mbus_code" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("i2c:ox08b40");
MODULE_ALIAS("of:N*T*Cnvidia,ox08b40");
MODULE_ALIAS("of:N*T*Cnvidia,ox08b40C*");

MODULE_INFO(srcversion, "0F30EE11AE82ADAC97EF4B9");
